=============================
Django Samplemed Rbac example
=============================

This is a installations sample.

